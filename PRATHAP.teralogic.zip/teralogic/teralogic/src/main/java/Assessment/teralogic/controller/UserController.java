package Assessment.teralogic.controller;

import Assessment.teralogic.entity.User;
import Assessment.teralogic.service.UserService;
import Assessment.teralogic.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//http://localhost:8081/api/user
@RestController
@RequestMapping("/api/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping
    public ResponseEntity<User> addOrUpdateUser(@RequestBody User user){
        try {
            User savedUser = userService.addOrUpdateUser(user);
            return ResponseEntity.ok(savedUser); // Return the saved user
        } catch (Exception e) {
            // Return an error response with proper type
            return null;
        }
    }

    @GetMapping
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }
}
