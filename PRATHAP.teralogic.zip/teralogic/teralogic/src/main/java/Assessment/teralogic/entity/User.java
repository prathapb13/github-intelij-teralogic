package Assessment.teralogic.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.util.*;


@Entity
@Data
@Table(name = "user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Unique ID for the user

    @Column(name = "username", nullable = false, unique = true)
    private String username;  // Username (unique and not null)

    @Column(name = "password", nullable = false)
    private String password;  // Password (encrypted, should not be null)

    @Column(name = "email", nullable = false, unique = true)
    private String email;  // Email address (unique and not null)

    @Column(name = "contact", nullable = false)
    private String contact;  // Contact number (e.g., phone number)

    @Column(name = "expiration_date")
    private Date expirationDate;  // Date type for expiration date

    @Column(name = "timeout")
    private Long timeout;  // Long type for timeout in milliseconds

    @Column(name = "date_time_format")
    private String dateTimeFormat;  // String for custom date/time format (e.g., "yyyy-MM-dd HH:mm:ss")

    @ElementCollection
    @CollectionTable(name = "role_names", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "role_name")
    private List<String> roleNames;  // List of role names

    @ElementCollection
    @CollectionTable(name = "scope_names", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "scope_name")
    private List<String> scopeNames;  // List of scope names

    @Column(name = "primary_group_name")
    private String primaryGroupName;  // String for primary group name

    @ElementCollection
    @CollectionTable(name = "secondary_group_names", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "secondary_group_name")
    private List<String> secondaryGroupNames;  // List of secondary group names

    @Column(name = "language")
    private String language;  // String for language (e.g., "en", "fr")

    @Column(name = "organization")
    private String organization;  // String for organization name

    @Column(name = "time_zone")
    private String timeZone;  // String for time zone (e.g., "UTC", "America/New_York")

    @Column(name = "memo")
    private String memo;  // String for memo or notes

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Long getTimeout() {
        return timeout;
    }

    public void setTimeout(Long timeout) {
        this.timeout = timeout;
    }

    public String getDateTimeFormat() {
        return dateTimeFormat;
    }

    public void setDateTimeFormat(String dateTimeFormat) {
        this.dateTimeFormat = dateTimeFormat;
    }

    public List<String> getRoleNames() {
        return roleNames;
    }

    public void setRoleNames(List<String> roleNames) {
        this.roleNames = roleNames;
    }

    public List<String> getScopeNames() {
        return scopeNames;
    }

    public void setScopeNames(List<String> scopeNames) {
        this.scopeNames = scopeNames;
    }

    public String getPrimaryGroupName() {
        return primaryGroupName;
    }

    public void setPrimaryGroupName(String primaryGroupName) {
        this.primaryGroupName = primaryGroupName;
    }

    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    public void setSecondaryGroupNames(List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
}
