package Assessment.teralogic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeralogicApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeralogicApplication.class, args);
	}

}
