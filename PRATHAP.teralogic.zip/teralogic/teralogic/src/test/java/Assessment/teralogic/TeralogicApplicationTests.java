package Assessment.teralogic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeralogicApplicationTests {

	@Test
	void contextLoads() {
	}

}
